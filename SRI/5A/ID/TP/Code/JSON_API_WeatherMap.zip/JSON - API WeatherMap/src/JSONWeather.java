/* Exemple d'usage d'un client HTTP avec le code retour
 *
 */ 
 
import java.io.*;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.Iterator;

public class JSONWeather {

    public final static void main(String[] args) throws Exception {
        String url = "http://api.openweathermap.org/data/2.5/weather?q=Toulouse&appid=cdc74bdfcf5cfeabbf19890354b53ca9"; // API Weather Map

		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);
		JSONParser parser = new JSONParser();
		
		// Ajout d'une ent�te
		request.addHeader("User-Agent", org.apache.http.params.CoreProtocolPNames.USER_AGENT);
		HttpResponse response = client.execute(request);

		if (response.getStatusLine().getStatusCode() == 200) { // ALL IS FINE!
		
			BufferedReader rd = new BufferedReader(
				new InputStreamReader(response.getEntity().getContent()));
			
			// lecture de la r�ponse
			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			try {
				Object obj = parser.parse(result+"");
			
				JSONObject json = (JSONObject) obj;
				JSONObject list = (JSONObject) json.get("main"); 
				long pressure = (Long) list.get("pressure");
				long humidity = (Long) list.get("humidity");
				System.out.println("Pression : " + pressure + " HPa\nHumidite : " + humidity + "%\n\n"); 

				JSONArray weather = (JSONArray) json.get("weather");
			
				Iterator iterator = weather.iterator();
					json = (JSONObject) iterator.next();
					String description = (String) json.get("description");
					System.out.println("Meteo : " + description); 
			}
			catch (ParseException e) {
				e.printStackTrace();
			}	
		}
    }

}