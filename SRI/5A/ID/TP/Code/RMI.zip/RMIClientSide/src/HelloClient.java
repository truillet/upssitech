import java.rmi.*;

public class HelloClient {
	public static void main(String args[]) 
	{
		try 
		{
      // rechercher une instance de type "HelloInterface" � l'adresse indiqu�e
			HelloInterface obj = (HelloInterface)	Naming.lookup("rmi://localhost:12345/mon_serveur_hello");
			
			// appel des m�thodes
			String msg = obj.say();
			System.out.println(msg);
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
