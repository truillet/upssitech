import java.rmi.*;
import java.rmi.server.*;


public class HelloServeur extends UnicastRemoteObject implements HelloInterface
{
	private String msg;
	public HelloServeur(String msg) throws java.rmi.RemoteException
	{
		super(); this.msg = msg;
	}

	public String say() throws java.rmi.RemoteException
	{
		System.out.println("Hello world: " + msg);
		return "Hello world: " + msg;
	}
	
	public static void main(String args[])
	{
		try 
		{
      // nouvelle instance HelloServeur
			HelloServeur obj = new HelloServeur("I'm the HelloServeur");
			
			// lancer automatiquement un annuaire RMIRegistry sur le port 12345
			// il existe une autre possibilit� en lan�ant rmiregistry depuis une ligne de commande !
			java.rmi.registry.LocateRegistry.createRegistry(12345);
			
			// enregistrer la classe dans l'annuaire
			Naming.rebind("rmi://localhost:12345/mon_serveur_hello",obj);
			
			System.out.println("HelloServer bound in registry");
		} 
		catch(Exception e)
		{
      e.printStackTrace();
    }
	}
}
