import java.io.*;
import java.util.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;

public class HorlogeClient {
   public static void main(String argv[]) {
      try {
         // create and initialize the ORB
         ORB orb = ORB.init(argv, null);
         // get the root naming context
         org.omg.CORBA.Object objRef =
            orb.resolve_initial_references("NameService");
         NamingContext ncRef = NamingContextHelper.narrow(objRef);
         NameComponent nc = new NameComponent("Horloge", " ");      
         // Resolve the object reference in naming
         NameComponent path[] = {nc};
         
          // La classe Helper fournit une fonction "narrow" pour obtenir un
          // objet sur lequel on peut invoquer les methodes
          Horloge horloge = HorlogeHelper.narrow(ncRef.resolve(path));
		
          // On invoque les m�thodes sur l�objet distant comme s�il s�agissait
          // d�un objet local
          System.out.println(horloge.get_time_string());
          ShortHolder heure = new ShortHolder();
          ShortHolder min = new ShortHolder();
          horloge.get_time_int(heure,min);
          System.out.println(""+heure.value+":"+min.value);
       }
       catch (Exception e)
       {
          System.out.println("Une exception a �t� lev�e");

       }   
   }
}

