import java.io.*;

import org.omg.CORBA.*;

public class HorlogeServer {
   public static void main(String args[]) {
      try{
         // create and initialize the ORB
         ORB orb = ORB.init(args, null);        
	
         // Creation instance
         HorlogeServant objet = new HorlogeServant();
         // Enregistrement aupres du BOA
         orb.connect(objet);
	
          // lancement du serveur
          System.out.println("Serveur lance sur l'adresse du bus CORBA \n"+ orb.object_to_string(objet));
          // GO
          java.lang.Object sync = new java.lang.Object();
          synchronized (sync) {
            sync.wait();
          }
        }        
     catch(Exception e) {
         System.err.println("ERROR: " + e.getMessage());
         e.printStackTrace(System.out);
      }
   }
}
