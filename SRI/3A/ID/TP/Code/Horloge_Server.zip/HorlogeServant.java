import java.io.*; 
import java.util.Date;

public class HorlogeServant extends _HorlogeImplBase {
 
    public String get_time_string() {
      return((new Date()).toLocaleString());
    }

    public void get_time_int(org.omg.CORBA.ShortHolder heure, org.omg.CORBA.ShortHolder min) {
      Date date = new Date();

      heure.value = (short) date.getHours();
      min.value = (short) date.getMinutes();
    }
}