/* 
 * exemple UDP  - envoi de trames udp sur le port 80
 * 
 *
 */
 
import java.net.*;
import java.io.*;


class clientUDP {
	InetAddress adresse;
	int Port;
	DatagramSocket socket;
	DatagramPacket emission;
	
	public clientUDP(String addr, String port)  throws SocketException, IOException, UnknownHostException {
		
		String texte="== DEBUT EMISSION DE TRAMES SUR LE PORT 80 JUSQU'AU MOT-CLE FIN ==";
		byte[] tampon = texte.getBytes();
		
		adresse = InetAddress.getByName(addr);
		Port = Integer.parseInt(port);

		socket = new DatagramSocket();

		// Cr�ation du BufferedReader connect� sur l'entr�e standard
		BufferedReader entree = new BufferedReader(new InputStreamReader(System.in));

    do {
      // Attente d'une entr�e de l'utilisateur
			texte = entree.readLine();
                   
			// Cr�ation du datagramme � envoyer
			tampon = texte.getBytes();
			emission = new DatagramPacket(tampon, tampon.length, adresse, Port);
	
			// Envoi du datagramme
			socket.send(emission);
    }   
    // Boucler tant qu'on n'a pas re�u le mot de la fin
    while(!texte.equals("FIN"));

	}
	
	// ======================
	// ARGUMENTS : adresse IP o� emettre + port
	public static void main(String args[]) {
		try {
			clientUDP u = new clientUDP(args[0], args[1]);
		}
			
		catch (Exception e)	{ }
	}
}