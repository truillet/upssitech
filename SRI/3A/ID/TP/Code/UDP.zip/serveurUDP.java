/* 
 * exemple UDP  - r�ception de trames udp sur le port 80
 * 
 *
 */
 
import java.net.*;
import java.io.*;


class serveurUDP {
	byte[] tampon;
	
	public serveurUDP()  throws SocketException, IOException {
		tampon = new byte[1024];
		String texte;
		
		DatagramSocket socket = new DatagramSocket(80); // utilsiation du port 80
		DatagramPacket reception = new DatagramPacket(tampon, tampon.length);
		
		System.out.println("== RECEPTION de TRAMES SUR LE PORT 80 ==");
		for (;;) {		
			socket.receive(reception);
		
			texte= new String(tampon, 0, reception.getLength());
			System.out.println("\nReception de : " + reception.getAddress().getHostName() + "\nsur le port : " + reception.getPort() + "\nTexte :" + texte);

		}

	}
	
	
	// ======================
	public static void main(String args[]) {
		try {
			serveurUDP u = new serveurUDP();
	  }
		catch (Exception e)	{
	  }
  }

}