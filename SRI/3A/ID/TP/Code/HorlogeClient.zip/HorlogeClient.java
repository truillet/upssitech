import java.io.*;
import java.util.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;

public class HorlogeClient {
   public static void main(String argv[]) {
      try {
         // create and initialize the ORB
         ORB orb = ORB.init(argv, null);
         
         /* Utilisation d'object to string */
          // ATTENTION : IL FAUT CHANGER L'ADRESSE DU BUS ET RECOMPILER !!!
          org.omg.CORBA.Object obj = orb.string_to_object("IOR:00000000000000...");
				
         
          // La classe Helper fournit une fonction "narrow" pour obtenir un
          // objet sur lequel on peut invoquer les methodes
          Horloge horloge = HorlogeHelper.narrow(obj);
		
          // On invoque les m�thodes sur l�objet distant comme s�il s�agissait
          // d�un objet local
          System.out.println(horloge.get_time_string());
          ShortHolder heure = new ShortHolder();
          ShortHolder min = new ShortHolder();
          horloge.get_time_int(heure,min);
          System.out.println(""+heure.value+":"+min.value);
       }
       catch (Exception e)
       {
          System.out.println("Une exception a �t� lev�e");

       }   
   }
}

