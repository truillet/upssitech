#include "Graphes.h"
#include <stdlib.h>
#include <stdio.h>


int main() {
	Graphe G;
	Arc a;
	printf("== Gestion du Graphe ==\n");
	G = initialiseGraphe();

	a = creerArc(1,2);
	ajouteArc(a,G);

	a = creerArc(2,1);
	ajouteArc(a,G);
	
	a = creerArc(2,2);
	ajouteArc(a,G);	
	
	printf("\nListe des arcs ajoutés\n");
	afficheArcs(G);

	if (existeArc(a,G)){
		afficheArc(a);
		printf("L'arc existe dans le Graphe\n");
	}
	
	return(1);
}
