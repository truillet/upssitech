#ifndef __GRAPHES_H__
#define __GRAPHES_H__
/*
 * Graphes.h
 */

typedef struct s_sommet *Sommet;
typedef struct s_arc *Arc;
typedef struct s_graphe *Graphe;

Graphe initialiseGraphe(); // permet d'ajouter des sommets au graphe

Arc creerArc(int,int);
void afficheArc(Arc);
void afficheArcs(Graphe);
void ajouteArc(Arc, Graphe); // ajoute l'arc au graphe
void supprimeArc(Arc, Graphe); //supprime l'arc au graphe
int existeArc(Arc, Graphe); // retourne 1 si l'arc a existe dans le graphe


int existeSommet(Sommet, Graphe); // retourne 1 si le sommet s existe dans le graphe

#endif