#include <stdio.h>
#include <stdlib.h>
#include <time.h>     
#include <ctype.h>  
#include "../include/stack.h"

#define FERME 0
#define OUVERT 1
#define LIGNES 10
#define COLONNES 10

//Labyrinthe
/*
int petitlaby[]=  
   {FERME, OUVERT, FERME, FERME, FERME, FERME,
    FERME, OUVERT, OUVERT, OUVERT, OUVERT, FERME,
    FERME, OUVERT, FERME, FERME, FERME, FERME,
    FERME, OUVERT, OUVERT, OUVERT, OUVERT, FERME,
    FERME, FERME, FERME, FERME, OUVERT, FERME} ;
*/

// Le labyrinthe va être représenté par un tableau d'entiers de LIGNES*COLONNES
void affiche_laby(int* laby){
    for (int i=0; i<LIGNES; i++){
        for (int j=0; j<COLONNES; j++){
            switch((int) *(laby+(i*LIGNES)+j)){ 
                case FERME: //FERME
                    printf("X");
                    break;
                case OUVERT: //OUVERT
                    printf(" ");
                    break;
            }
        }
        printf("\n");
    }
}

int creation_laby(int* laby){
    for (int i=0; i<LIGNES; i++){
        for (int j=0; j<COLONNES; j++){		
            if ((rand()%10 <= 4) || (i==0 && j==1) || (i==1 && j==1)){
                *(laby +(i*LIGNES)+j) = OUVERT;
            }
			else {
                *(laby +(i*LIGNES)+j) = FERME;
            }
			// fermer les contours
            if((i==0 && j!=1) || (j==0) || (j==COLONNES-1)){
                *(laby +(i*LIGNES)+j) = FERME;
            }
        }
    }
	return(1);
}

/** MAIN */
int main (int argc, char * argv[]){
    // Générer la graine aléatoire
    srand(time(NULL));

    int* laby;
    char yes_or_not = 'n';
    // allocation de la memoire nécessaire
    laby = (int*) malloc(sizeof(int)*LIGNES*COLONNES);

    while (toupper(yes_or_not) != 'Y'){
        creation_laby(laby);
        affiche_laby(laby);
        printf("\n[Y/n]\n");
        scanf("%c",&yes_or_not);
        fflush(stdin);
    }    
    printf(".: Labyrithe créé :.\n");
    
	/** Tester et trouver un chemin ... */
    Stack pile = stack();
    Step pas = step(0,1,1,1);
    push(pile,pas);
	
    return 0;
}
