#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "../include/maLibMath.h"

typedef struct Point{
    float x;
    float y;
    float z;
}Point_s;

typedef struct Vecteur{
    float x;
    float y;
    float z;
}Vecteur_s;

typedef struct Equation
{
    float a;
    float b;
    float c;
    float d;
}Equation_s;

//Getter
float getX(Point p){
    return p->x;
}

float getY(Point p){
    return p->y;
}

float getZ(Point p){
    return p->z;
}

//Demande les coordonnées du point
Point Demande_Point(){
    float x,y,z;

    printf("Entrez x : ");
    scanf("%f",&x);
    fflush(stdin);
    printf("Entrez y : ");
    scanf("%f",&y);
    fflush(stdin);
    printf("Entrez z : ");
    scanf("%f",&z);
    fflush(stdin);

    Point pt = Creer_Point(x,y,z); //Création du point

    return pt;
}

//Création du point
Point Creer_Point(float x, float y, float z){
    //Création et allocation de la mémoire
    Point pt;
    pt = (Point)malloc(sizeof(Point_s));
    
    //Stockage
    pt->x=x;
    pt->y=y;
    pt->z=z;

    return pt;
}

//Création du vecteur
Vecteur Vectorise(Point Pt1, Point Pt2){
    //Création et allocation de la mémoire
    Vecteur v;
    v = (Vecteur)malloc(sizeof(Vecteur_s));

    //Stockage
    v->x=(Pt2->x - Pt1->x);
    v->y=(Pt2->y - Pt1->y);
    v->z=(Pt2->z - Pt1->z);

    return v;
}

//Affiche Vecteur
void Affiche_Vecteur(Vecteur v){
    printf("(%.2f,%.2f,%.2f)\n",v->x,v->y,v->z);
}

//Affiche Point
void Affiche_Point(Point pt){
    printf("(%.2f,%.2f,%.2f)\n",pt->x,pt->y,pt->z);
}

//Produit Vectoriel
Vecteur Produit_Vectoriel(Vecteur V1, Vecteur V2){
    //Création et allocation de la mémoire
    Vecteur v;
    v = (Vecteur)malloc(sizeof(Vecteur_s));

    //Calculs
    v->x=V1->y * V2->z - V2->y * V1->z;
    v->y=V1->z * V2->x - V2->z * V1->x;
    v->z=V1->x * V2->y - V2->x * V1->y;

    return v;
}

//Produit Scalaire
float Produit_Scalaire(Vecteur V1, Vecteur V2){
    return (V1->x * V2->x + V1->y * V1->y + V1->z * V2->z);
}

//Norme
float Norme(Vecteur V){
    return (sqrt(pow(V->x,2) + pow(V->y,2) + pow(V->z,2)));
}

//Renvoie l'équation du plan
Equation Equation_Plan(Point Pt1, Point Pt2, Point Pt3){
    //Création et allocation de la mémoire
    Equation Eq;
    Eq = (Equation)malloc(sizeof(Equation_s));

    Vecteur v1 = Vectorise(Pt1,Pt2);
    Vecteur v2 = Vectorise(Pt1,Pt3);
    Vecteur n = Produit_Vectoriel(v1,v2);
    //Stockage
    Eq->a = n->x;
    Eq->b = n->y;
    Eq->c = n->z;
    Eq->d = - ((n->x)*(Pt1->x) + (n->y)*(Pt1->y) + (n->z)*(Pt1->z));

    return Eq;
}

//Affiche l'équation
void Affiche_Equation_Plan(Equation Eq){
    printf("%.2fx + %.2fy + %.2fz + %.2f = 0\n",Eq->a,Eq->b,Eq->c,Eq->d);
}
