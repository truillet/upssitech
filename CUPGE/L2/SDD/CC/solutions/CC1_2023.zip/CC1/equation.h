#ifndef __EQUATION_H__
#define __EQUATION_H__

/* définition opaque de la structure */
typedef struct s_solution* Solution;
typedef struct s_equation* Equation;

/* définition des fonctions */
Equation equation(void);
Solution determinant(Equation e);
void print_determinant(Solution s);
void setC(Equation e, float c);
void setD(Equation e, float d);
Solution solve(Equation e);

#endif

