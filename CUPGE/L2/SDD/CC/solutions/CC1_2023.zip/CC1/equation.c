#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "equation.h"

enum type {ERREUR=0, REEL, COMPLEXE};

struct s_complexe {
	float Re;
	float Im;
};

union u_solution {
	struct s_complexe c;
	float r;
};

struct s_solution {
	union u_solution solution;
	enum type t;
};

struct s_equation {
	float c;
	float d;
};

Equation equation() {
	Equation e = malloc(sizeof(struct s_equation));
	return e;
}


Solution determinant(Equation e) {
	Solution s = malloc(sizeof(struct s_solution));
	// calcul determinant
	float delta = pow(e->d,2) + (4.0/27) * pow(e->c,3);
	if (delta >=0) {
		s->t = REEL;
		s->solution.r = delta;
	}
	else {
		s->t = COMPLEXE;
		s->solution.c.Re = 0.0;
		s->solution.c.Im = sqrt(-delta);
	}
	return(s);
}


void print_determinant(Solution s) {
	switch  (s->t) {
		case REEL:
			printf("déterminant %.2f\n",s->solution.r);
			break;
		case COMPLEXE:
			printf("déterminant %.2f*i\n", sqrt(s->solution.c.Im));
			break;
		default:
			printf("Erreur\n");
			break;
	}
}

void setC(Equation e, float c){
	e->c = c;
}

void setD(Equation e, float d){
	e->d = d;
}

Solution solve (Equation e){
	Solution s = malloc(sizeof(struct s_solution));
	// calcul determinant
	Solution det = determinant(e);

	switch (det->t) {
		case REEL: //  cas à traiter avec les réels
			float x = pow((-e->d - sqrt(det->solution.r))/2,1/3) + pow((-e->d + sqrt(det->solution.r))/2, 1/3);
			s->t = REEL;
			s->solution.r = x;
			break;
		case COMPLEXE : // det <0
			// à traiter avec les complexes
			s->t = COMPLEXE;
			break;
		default:
			break;
	}
	return(s);
}

/* === MAIN === */
int main(int argc, char * argv[]) {
	// création equation
	Equation e = equation();
	setC(e,-2);
	setD(e,4);
	// résolution
	Solution s = determinant(e);
	printf("== DETERMINANT ==\n");
	print_determinant(s);
	printf("== SOLUTION ==\n");
	s = solve(e);
	if (s->t == REEL)
		printf("solution réelle : %.2f\n", s->solution.r);
	else 
		printf("solution réelle avec determinant négatif\n");
	return(1);
}
