# devinette

# l'ordi pense à un nombre
nombre = ceil(rand()*100);

trouve = false;
coups=0;
while (trouve == false)
  rep = input("Entrez un nombre pour deviner celui que j'ai choisi : ");
  coups++;
  if rep>nombre
    disp("C'est moins !");
  elseif rep<nombre
    disp("C'est plus !");
  else # gagne
    disp("C'est GAGNE !"); 
    trouve = true;
  end  
end
printf("Il vous a fallu %d coup(s) pour gagner\n", coups);