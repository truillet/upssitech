% cosinus s�rie enti�re
x=0:.01:2*pi;

subplot(1,3,1)
  plot(x,cos(x));
  hold on
  plot(x,mycos(x,1));
  axis([0 2*pi]);
  legend('cos(x)', 'mycos(x,1)')
  
subplot(1,3,2);
  plot(x,cos(x));
  hold on
  plot(x,mycos(x,5));
  axis([0 2*pi]);
  legend('cos(x)', 'mycos(x,5)')
  
subplot(1,3,3);
  plot(x,cos(x));
  hold on
  plot(x,mycos(x,20));
  axis([0 2*pi]);
  legend('cos(x)', 'mycos(x,20)')