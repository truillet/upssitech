% papillon T. Fay

% calcul des coordonn�es polaires
theta = 0:0.01:2*pi
r = exp(cos(theta)) - 2*cos(4*theta)

% passage dans les coordonn�es cart�siennes
x = r.*cos(theta)
y = r.*sin(theta)

% afficher le r�sultat
plot(x,y);
