% exercice2
% on d�finit 1 ligne et 2 colonnes

subplot(1,3,1);
  % d�finir 101 valeurs entre 0 et 2pi
  X=linspace(0,2*pi,101);
  Y=exp(-X).*sin(4*X);
  plot(X,Y);
  grid on;

subplot(1,3,2);
  % d�finir l'ensemble des valeurs de -1 � 1 avec un pas de .1
  X2 = [-1:.1:1];
  Y2 = X2.^2;
  plot(X2,Y2,"r");
  grid on;

subplot(1,3,3);
  % on utilise le m�me jeu de donn�es qua dans le 2
  Y3 = X2.^2.*sin(X2).*exp(-X2);
  plot(X2,Y3,"g");
  grid on;


