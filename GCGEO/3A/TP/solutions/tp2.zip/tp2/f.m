function y=f(x)
  y=exp(3*x)-x.^2;
end