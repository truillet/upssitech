% dichotomie

epsilon = 10^-6;
a = input("Entrez une borne inferieure : ");
b = input("Entrez une borne inferieure : ");

if f(a)*f(b)<0
    % r�p�ter jusqu'� ce que la diff�rence soit > epsilon
  while abs(b-a) > epsilon
    if f((a+b)/2)*f(a) < 0
      b = (a+b)/2;
    elseif f((a+b)/2)*f(a) > 0
       a = (a+b)/2;
    end
  end
  printf("La racine approchee est %.2f\n",a);
end
