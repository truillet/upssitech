% dichotomie

a = input("Entrez une borne inferieure : ");
b = input("Entrez une borne inferieure : ");
n = input("Entrez un nombre d'iterations desirees : ");

if f(a)*f(b)<0
  # r�p�ter n fois
  for i=1:n
    if f((a+b)/2)*f(a) < 0
      b = (a+b)/2;
    elseif f((a+b)/2)*f(a) > 0
       a = (a+b)/2;
    end
  end
  printf("La racine approchee est %.2f\n",a);
end
