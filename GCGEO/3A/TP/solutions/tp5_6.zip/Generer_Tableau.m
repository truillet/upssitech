function T=Generer_Tableau(n)
	T=[];
	for i=1:n
		T=[T round(rand()*100000)];
	end
end