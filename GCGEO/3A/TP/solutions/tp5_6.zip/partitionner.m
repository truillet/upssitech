function [p,T]=partitionner(T,premier,dernier)
  pivot = T(premier);
  p = premier;
  for i=premier+1:dernier
    if T(i) <= pivot
      p=p+1;
      % echange
      aux = T(i);
      T(i)=T(p);
      T(p)=aux;
    endif
  endfor
  % echange
  aux = T(premier);
  T(premier)=T(p);
  T(p)=aux;
endfunction
