function T= Creer_Tableau()
	T=[];
	val = input('Entrer une valeur - \'$\' pour finir'=;
	
	while val != '$'
		T=[T val];
		val = input('Entrer une valeur - \'$\' pour finir'=;
	end
end
