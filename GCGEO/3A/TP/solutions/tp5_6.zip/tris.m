% script

% tableaux � remplir
X=[];
TB=[];
TQ=[];

% ici, on ne calcule qu'une fois le temps : il faudrait r�p�ter l'op�ration
% plusieurs fois afin de minimiser les probl�mes

for i=1:500:3001 % de 1 � 5001 �l�ments
  T= Generer_Tableau(i); % g�n�ration d'un tableau de i �l�ments
  printf("Nombre elements courants : %d\n",i);
  tic();
  tri_bulles(T);
  tps=toc();
  TB=[TB tps]; % ajout du temps du tri � bulles
  
  tic();
  tri_quicksort(T);
  tps=toc(); 
  TQ=[TQ tps]; % ajout du temp du tri quicksort
  
  X=[X i]; % ajout du nombre d'�l�ments sur l'axe des abscisses
endfor

% affichage
plot(X,TB);
hold on
plot(X,TQ,"r");
xlabel('nbre elements');
ylabel('temps');
legend('Bulles','QuickSort');