function T=Tri_Rapide(T,premier,dernier)
  if premier<dernier
    [pivot,T] = partitionner(T,premier, dernier);
    T=Tri_Rapide(T,premier,pivot-1);
    T=Tri_Rapide(T,pivot+1,dernier);
  endif
endfunction
