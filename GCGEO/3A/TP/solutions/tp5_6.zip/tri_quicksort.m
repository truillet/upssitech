function T=tri_quicksort(T)
  taille = length(T);
  T=Tri_Rapide(T,1,taille);
endfunction
