function T=Insere_Element(T,p_init,p_fin)
	if (p_init > p_fin)
		v = T(p_init);
		T(p_fin+1:p_init)=T(p_fin:p_init-1);
		T(p_fin)=v;
	end
end	