function T = tri_bulles(T)
  taille= length(T);
  for i = taille:-1:1
    for j = 2:i
      if T(j-1)> T(j)
         % �change
         aux= T(j);
         T(j)=T(j-1);
         T(j-1)=aux;
      endif
    endfor
  endfor
endfunction
