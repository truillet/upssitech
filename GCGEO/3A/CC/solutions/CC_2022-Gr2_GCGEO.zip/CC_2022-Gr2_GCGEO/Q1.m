# Script Q1

# Question 1

# placement initial de 5000 � sur 4 ans
somme1 = 5000;
somme2 = 5000;

for i=1:16 # 16  trimestres de placement
  somme1 = somme1*1.02 -10;
end

for i=1:4 # 4 ans de placement
  somme2 = somme2*1.06 - 4;
end

printf("Rendement du contrat 1 : %.2f\n", somme1);
printf("Rendement du contrat 2 : %.2f\n", somme2);

