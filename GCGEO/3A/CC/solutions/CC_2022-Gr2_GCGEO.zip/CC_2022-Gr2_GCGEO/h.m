function p=h(n)
  p=0;
  for i=1:n
    p=p+(1/i^2);
  endfor
  p = sqrt(6*p);
end

