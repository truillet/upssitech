# Script Q2

subplot(2,1,1);
# cr�ation des 500 1ers termes
T1 = [];
for i=1:500
  T1 = [T1 g(i)];
end
  plot(T1);
  axis([0,500,3,3.3]);

subplot(2,1,2);
T2 = [];
for i=1:500
  T2 = [T1 h(i)];
end
  plot(T2, "r");
  axis([0,500,3,3.3]);
