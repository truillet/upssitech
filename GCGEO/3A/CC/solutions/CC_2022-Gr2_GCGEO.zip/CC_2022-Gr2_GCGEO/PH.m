function [x,y,z]=PH(t,v)
  x = 6*((t+v)/2);
  y = 3*((t-v)/2);
  z = t.*(v/0.2);
end
