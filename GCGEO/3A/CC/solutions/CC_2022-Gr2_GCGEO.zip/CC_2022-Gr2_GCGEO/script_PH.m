% script PH

t=[-pi:0.1:pi+.1];
u=[-pi:.1:pi];
[T,U]=meshgrid(t,u);

[X,Y,Z] = PH(T,U);
surf(X,Y,Z);
xlabel('x');
ylabel('y');
zlabel('z');
title("Parabolo�de Hyperbolique");
grid on
