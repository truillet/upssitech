function p=h(n)
  p=1;
  for (i=1:n)
    p=p*((4*i.^2)/(4.*i.^2-1));
  endfor
  p=2*p;
endfunction
