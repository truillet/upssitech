function z=f(x,y)
  z= (2.*x.*y)./(x.^2 + y.^2);
endfunction
