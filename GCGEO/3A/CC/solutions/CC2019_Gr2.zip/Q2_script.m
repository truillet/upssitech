# Q2
P=[];
S=[];
for i=1:500
  P=[P h(i)];
  S=[S g(i)];
endfor
hold off
subplot(1,2,1)  
  plot(P);
  axis([0 500 3.0 3.3])
  title("h(n)");
  grid on 
  
subplot(1,2,2)  
  plot(S,"r");
  axis([0 500 3.0 3.3])
  grid on 
  title("g(n)");
 
