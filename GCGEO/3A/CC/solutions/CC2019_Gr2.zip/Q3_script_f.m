% espace de d�finition
x=[-2:0.1:2];
y=[-2:0.1:2];

[X,Y] = meshgrid(x,y);
Z=f(X,Y);
surf(Z);
xlabel('x');
ylabel('y');
zlabel('z');
title("Ma Fonction 3D")
legend("f(x,y) = 2xy/(x^2+y^2)")
print("f.png","-dpng");
