function [x,y,z] = f2(u, v)
  x = v.*cos(u);
  y = v.*sin(u);
  z = 2.*u;
endfunction
