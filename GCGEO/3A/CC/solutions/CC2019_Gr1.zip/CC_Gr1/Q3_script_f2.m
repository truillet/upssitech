% espace de d�finition
u=[-4:0.1:4];
v=[-4:0.1:4];

[U,V] = meshgrid(u,v);
[X,Y,Z] = f2(U,V);
mesh(X,Y,Z);
xlabel('x');
ylabel('y');
zlabel('z');
title("Ma Fonction 3D")
legend("f2(u,v)")
print("f2.jpg","-djpg");
