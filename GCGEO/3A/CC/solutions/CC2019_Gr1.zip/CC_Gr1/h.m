function p=h(n)
  s=0;
  for (0=1:n)
    s=s+((-1)^n/(2*n+1));
  endfor
  s=4*s;
endfunction
