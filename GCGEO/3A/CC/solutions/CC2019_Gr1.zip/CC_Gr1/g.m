function s=g(n)
  s=0;
  for i=1:n
    s= s + 1/(i.^2);
  endfor
  s = sqrt(6*s);
endfunction
