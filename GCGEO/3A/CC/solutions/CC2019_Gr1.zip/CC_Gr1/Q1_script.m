#Q1_script

n=1;
erreur=1;
while erreur>10.^-6
  y=expa_Taylor(2,n,3)
  erreur=abs(exp(1)-y);
  n++;
endwhile

printf("n= %d\n",n--);
