function y=expa_Taylor(x,a,n)
  y=1;
  for i=1:n
    y=y+ (a^i * x^i)/factorial(i);
  endfor
endfunction
