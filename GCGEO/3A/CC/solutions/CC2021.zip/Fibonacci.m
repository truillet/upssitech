function F = Fibonacci(n)
  if n==0 
    F=0;
  elseif n==1
    F=1;
  else 
    SF = [0 1];
    for i=3:n
      SF(i) = SF(i-1) + SF(i-2);
    end
    F=SF(n);  
  end
end