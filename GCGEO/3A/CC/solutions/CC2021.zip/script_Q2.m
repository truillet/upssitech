% script Q2
hold off;
clear all;
X=[1:15];
for i=1:15
  Y1(i)=(1+sqrt(5))/2;
  Y2(i)=phi(X(i));
end
  plot(X,Y1);
  hold on;
  plot(X,Y2);
  title("Phi, nombre d'Or");
  legend("phi","phi(bonacci)");
