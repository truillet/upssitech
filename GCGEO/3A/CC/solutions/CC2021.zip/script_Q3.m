% script 
t=[-1:0.1:1];
v=[0:.1:2*pi+0.1];

[T,V]=meshgrid(t,v);

[X,Y,Z]=moebius(T,V);
surf(X,Y,Z);
xlabel('x');
ylabel('y');
zlabel('z');
title('Ruban de Moebius');
print("moebius.jpg","-djpg");