% script Q1

% calcul de cosh(pi)
ref=cosh(pi);
n=0;
while (abs(ref - cosh_Taylor(pi,n)) > 10^-6)
  n++;
end

printf("Valeur minimale de n: %d\n",n);
