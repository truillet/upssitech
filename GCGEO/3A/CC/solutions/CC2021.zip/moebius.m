function [x,y,z] = moebius(t,v)
  x=(1+(t./2).*cos(v./2)).*cos(v);
  y=(1+(t./2).*cos(v./2)).*sin(v);
  z=(t./2).*sin(v./2);
end
