function p = phi(n)
  p = Fibonacci(n)/Fibonacci(n-1);
end