function S=cosh_Taylor(x,n)
  S=0;
  for (i=0:n)
    S=S + (x^(2*i))/factorial(2*i);
  endfor
end