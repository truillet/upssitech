% Q3_graphisme

u=[0:0.1:2*pi+.1];
v=[0:0.1:2*pi+.1];
[U,V]=meshgrid(u,v);

[X,Y,Z] = michele(U,V);
mesh(X,Y,Z);
xlabel('x');
ylabel('y');
zlabel('z');
title('Tore')
colorbar('South')
