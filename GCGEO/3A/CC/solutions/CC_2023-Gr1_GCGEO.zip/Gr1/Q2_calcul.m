% == Calcul et affichage

a=10;
X=[-7:0.1:7]


Y=1./(a-X);

Y1=f(X,10,1);
Y3=f(X,10,3);
Y7=f(X,10,7);

hold off
plot(X,Y);
hold on
plot(X,Y1)
plot(X,Y3)
plot(X,Y7)

axis([-7 7])
grid on
xlabel("abscisse x")
ylabel("ordonn�e y")
title("Approximation de 1/(10-x)");
legend("1/(10-x)", "f(x,10,1)", "f(x,10,3)", "f(x,10,7)")

