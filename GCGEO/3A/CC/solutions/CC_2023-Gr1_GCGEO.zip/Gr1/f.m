function y=f(x,a,n)
  y=0;
  for (i=0:n)
    y = y + (1/a^(i+1)).*(x.^i);
  endfor
end
