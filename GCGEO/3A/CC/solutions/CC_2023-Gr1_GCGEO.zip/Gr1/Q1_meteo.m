% M�teo

M = load('-ascii','toulouse-meteo_25_10_23.txt')

% Extraire le taux d'humidit� (1�re colonne et la pluie (colonne 3)
Hum = M(:,1)
Pluie = M(:,3)*10;

subplot(2,1,1)
  plot(Hum);
  xlabel('Journ�e du 25/10/2023')
  ylabel("Humidit�")
  title("M�t�o � Toulouse")
subplot(2,1,2)
  plot(Pluie,"r")
  xlabel('Journ�e du 25/10/2023')
  ylabel("mm de pluie")
  ylim([0,15])
  text(40,10, sprintf("Pluie : %.2f mm",sum(Pluie)));


