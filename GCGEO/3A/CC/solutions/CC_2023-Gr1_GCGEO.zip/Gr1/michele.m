function [x,y,z] = michele(u,v)
  a=1;
  r=.5;
  x=(a+ r.*cos(u)).*cos(v);
  y=(a+ r.*cos(u)).*sin(v);
  z=r.*sin(u);
end
