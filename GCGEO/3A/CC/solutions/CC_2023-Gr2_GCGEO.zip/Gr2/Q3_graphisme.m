% entonnoir

u=[0:0.1:2*pi+.1];
v=[0:0.1:2*pi+.1];
[U,V]=meshgrid(u,v);

[X,Y,Z]=entonnoir(U,V);
mesh(X,Y,Z);
xlabel('x - abscisse');
ylabel('y - ordonn�e');
zlabel('z');
title('Entonnoir')
colorbar('East')
