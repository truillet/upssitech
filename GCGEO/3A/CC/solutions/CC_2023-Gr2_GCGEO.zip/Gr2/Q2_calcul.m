% ==

X=[0:0.1:50]
a=0.1;

Y=e.^(a*X);

Y1=g(X,0.1,1);
Y5=g(X,0.1,5);
Y10=g(X,0.1,10);
hold off
plot(X,Y);
hold on
plot(X,Y1)
plot(X,Y5)
plot(X,Y10)
axis([0 50, 0 150])
grid on
xlabel("abscisse x")
ylabel("ordonn�e y")
title("Approximation de e^.1x");
legend("e^.1x", "f(x,.1,1)", "f(x,.01,5)", "f(x,.1,10)")

