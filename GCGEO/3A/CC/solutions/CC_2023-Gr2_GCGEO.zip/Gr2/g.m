function y=g(x,a,n)
  y=0;
  for (i=0:n)
    y = y + ((a.^i)./factorial(i)).*(x.^i);
  endfor
end
