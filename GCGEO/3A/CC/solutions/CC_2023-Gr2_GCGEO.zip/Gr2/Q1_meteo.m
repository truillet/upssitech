% M�teo

M = load('-ascii','toulouse-meteo_01_11_23.txt')

% Extraire la pression (2�me colonne et la temp�rature (colonne 4)
Pression = M(:,2)/100
Temperature = M(:,4);

subplot(2,1,1)
  plot(Pression);
  xlabel('Journ�e du 01/11/2023')
  ylabel("Pression HPa")
  title("M�t�o � Toulouse")
subplot(2,1,2)
  plot(Temperature,"r")
  xlabel('Journ�e du 01/11/2023')
  ylabel("�C")
  ylim([0,15])
  text(40,10, sprintf("Temperature moyenne : %.2f �C",mean(Temperature)));


