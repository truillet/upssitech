function [x,y,z] = entonnoir(u,v)
  a=2;
  c=2;

  x=a*sqrt(1+u.^2).*cos(v);
  y=a*sqrt(1+u.^2).*sin(v);
  z=c*u;
end

