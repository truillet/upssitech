function y=mycos(x,n)
  y=1;
  for k=1:n
    y = y + ((-1).^k).*(x.^(2*k)/factorial(2.*k));
  end  
endfunction
