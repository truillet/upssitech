% papillon T. Fay

theta = 0:0.01:2*pi
r = exp(cos(theta)) - 2*cos(4*theta)

x = r.*cos(theta)
y = r.*sin(theta)

plot(x,y);
