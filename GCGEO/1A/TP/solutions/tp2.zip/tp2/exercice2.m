# exercice2

X=linspace(0,2*pi,101); 
Y=exp(-X).*sin(4*X); 

subplot(1,3,1);
plot(X,Y);
grid on;

subplot(1,3,2);
X2 = [-1:.1:1];
Y2 = X2.^2;
plot(X2,Y2,"r");
grid on;

subplot(1,3,3);
Y3 = X2.^2.*sin(X2).*exp(-X2);
plot(X2,Y3,"g");
grid on;


