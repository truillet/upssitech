# Exercice 4

x=input('Entrez une valeur : ');

X=0:0.1:x;
Y=cos(X);
MY1=MonCos(X,1);
MY5=MonCos(X,5);
MY20=MonCos(X,20);
subplot(4,1,1);
plot(X,Y);
title('Calcul de cos(x)');
subplot(4,1,2);
plot(X,MY1);
legend('S�rie enti�re 1 terme');
subplot(4,1,3);
plot(X,MY5);
legend('S�rie enti�re 5 termes');
subplot(4,1,4);
plot(X,MY20);
legend('S�rie enti�re 20 termes');

  