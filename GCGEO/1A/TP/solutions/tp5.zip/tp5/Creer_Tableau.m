function T=Creer_Tableau()
  # créer un tableau vide
  T = [];
  a  = input("Entrez une valeur ('$' pour terminer) : ");
  while a != '$'
    T = [T a];
    a  = input("Entrez une valeur ('$' pour terminer) : ");
  end
end  