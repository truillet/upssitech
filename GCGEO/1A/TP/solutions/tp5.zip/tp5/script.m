T=Genere_Tableau(10)
T=tri_a_bulles(T)