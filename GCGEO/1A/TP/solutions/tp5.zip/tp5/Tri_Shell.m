function T=Tri_Shell(T)
  pas = 0;
  longueur=length(T);
  
  while pas < longueur
    pas = (3*pas)+1;
  end
  
  while pas > 0
    pas = int16(pas)/3;
    
    for i=pas+1:longueur    
      valeur = T(i);
      j = i;
      
      while j>(pas) && T(j-pas)> valeur
        T(j)=T(j-pas);
        j=j-pas;
      end
      T(j) = valeur;
    end
  end
end