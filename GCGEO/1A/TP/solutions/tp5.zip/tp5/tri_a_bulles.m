function T=tri_a_bulles(T)
    n= length(T);
    for i=n:-1:1
      for j=2:i
        if T(j-1)>T(j)
          temp = T(j-1);
          T(j-1)=T(j);
          T(j)=temp;
        end
      end
    end
 end  