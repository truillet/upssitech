function T=Inserer_Element(T, p_init, p_fin)
  ELEM = T(p_init);
  
  for i=p_init:-1:p_fin+1
    T(i) = T(i-1);
  end
  T(p_fin)=ELEM;
end