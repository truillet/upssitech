# script

O = Creer_Point(0,0,0);
A = Creer_Point(1,1,0);
B = Creer_Point(5,1,-2);
C = Creer_Point(3,4,1);

# Calcul du centre de gravit�
# 3 vAG = vAB + vAC
# vAO + vOG = 1/3(vAB + vAC) --> vOG = 1/3(vAB + vAC) - vAO
vOG = (1/3 * (Vectorise(A,B) + Vectorise(A,C))) - Vectorise(A,O);

hold off
Affiche_Point(vOG); # math�matiquement faux mais :)
text(vOG(1),vOG(2),vOG(3),"G");
hold on

# Affiche perim�tre + surface
# Perimètre = ||vAB|| + ||vBC|| + ||vCA||
Perimetre = Norme(Vectorise(A,B)) + Norme(Vectorise(B,C)) + Norme(Vectorise(C,A));
t= sprintf("Le perimetre du triangle est de %.2f\n",Perimetre);

# Surface S=1/2 ||vAB ^ vAC||
Surface = 1/2 * Norme(Produit_Vectoriel(Vectorise(A,B), Vectorise(A,C)));
t = sprintf("%s\nLa surface du triangle est de %.2f\n",t, Surface);

# Affichage des figures
Affiche_Triangle(A,B,C);
Equation = Equation_Plan(A,B,C);
Affiche_Plan(Equation);
xlabel("x");
ylabel("y");
zlabel("z");

# on finit le titre
t= sprintf("%s\nEquation du plan : (%.2f)x+(%.2f)y+(%.2f)z+(%.2f)=0",t, Equation(1),Equation(2),Equation(3),Equation(4));
title(t);
