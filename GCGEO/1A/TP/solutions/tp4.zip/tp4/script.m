# script

O = Creer_Point(0,0,0);
A = Creer_Point(1,1,0);
B = Creer_Point(5,1,0);
C = Creer_Point(3,4,0);

# Calcul du centre de gravité
# 3 vAG = vAB + vAC
# vAO + vOG = 1/3(vAB + vAC) --> vOG = 1/3(vAB + vAC) - vAO 
vOG = (1/3 * (Vectorise(A,B) + Vectorise(A,C))) - Vectorise(A,O);

hold off
Affiche_Point(vOG); # mathématiquement faux mais :)
text(vOG(1),vOG(2),vOG(3),"G"); 
hold on 

# Affiche perimètre + surface
# Perimètre = ||vAB|| + ||vBC|| + ||vCA||
Perimetre = Norme(Vectorise(A,B)) + Norme(Vectorise(B,C)) + Norme(Vectorise(C,A)); 
printf("Le perimetre du triangle est de %.2f\n",Perimetre);


# Surface S=1/2 ||vAB ^ vAC||
Surface = 1/2 * Norme(Produit_Vectoriel(Vectorise(A,B), Vectorise(A,C)))
printf("La surface du triangle est de %.2f\n",Surface);

Affiche_Triangle(A,B,C);
Equation = Equation_Plan(A,B,C);
Affiche_Plan(Equation);