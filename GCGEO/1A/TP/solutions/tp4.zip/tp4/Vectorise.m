function V = Vectorise(P1,P2)
  V = P2-P1;
end  