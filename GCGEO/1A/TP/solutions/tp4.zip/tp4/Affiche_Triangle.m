function Affiche_Triangle(Pt1,Pt2,Pt3)
  X = [Pt1(1) Pt2(1), Pt3(1) Pt1(1)];
  Y = [Pt1(2) Pt2(2), Pt3(2) Pt1(2)];
  Z = [Pt1(3) Pt2(3), Pt3(3) Pt1(3)];
  plot3(X,Y,Z, "k");
end