function PS = Produit_Scalaire(V1,V2)
  PS = V1(1)*V2(1) + V1(1)*V2(1) + V1(3)*V1(3);
end  