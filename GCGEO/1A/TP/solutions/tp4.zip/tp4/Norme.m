function N=Norme(V)
  N = sqrt(V(1)^2 + V(2)^2 + V(3)^2);
end  