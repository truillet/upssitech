function PV=Produit_Vectoriel(V1,V2)
  PV(1) = V1(2)*V2(3) - V1(3)*V2(2);
  PV(2) = V1(3)*V2(1) - V1(1)*V2(3);
  PV(3) = V1(1)*V2(2) - V1(2)*V2(1);
end  