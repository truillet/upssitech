function Affiche_Point(P)
  plot3(P(1),P(2),P(3),"or");
end  