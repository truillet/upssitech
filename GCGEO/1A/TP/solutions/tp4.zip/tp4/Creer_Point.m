function P = Creer_Point(x,y,z)
  P = [x;y;z];
end  