function P = Demande_Point()
  P(1) = input('Entrez la coordonnee en x : ')
  P(2) = input('Entrez la coordonnee en y : ')
  P(3) = input('Entrez la coordonnee en z : ')
end  