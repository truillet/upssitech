function Eq=Equation_Plan(Pt1,Pt2,Pt3)
  V1 = Vectorise(Pt1,Pt2);
  V2 = Vectorise(Pt1,Pt3);
  
  # calcul de la normale au plan
  n = Produit_Vectoriel(V1,V2);
  # quel que soit M appartenant au Plan, vecteur(Pt1,M) scalire N = 0
  Eq(1) = n(1);
  Eq(2) = n(2);
  Eq(3) = n(3);
  Eq(4) = -(Pt1(1)*n(1) + Pt1(2)*n(2) + Pt1(3)*n(3));
  
end