function Affiche_Plan(Eq)
  # on a l'�quation

  x = [-5:0.1:5];
  y = [-5:0.1:5];

  [X,Y] = meshgrid(x,y);
  if Eq(3) !=0 # le plan est en 3D
    Z = -(Eq(1)*X + Eq(2)*Y + Eq(4))/Eq(3);
    mesh(X,Y,Z);
  elseif Eq(2) !=0 # dans le plan X,Y
    Y = -(Eq(1)*X+Eq(4))/Eq(2);
    mesh(X,Y,Z);
  else
    # A faire ...
  end

end
