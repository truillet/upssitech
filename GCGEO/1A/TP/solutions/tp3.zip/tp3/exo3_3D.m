# exercice 4

hold off
X = [0:0.1:30]; # = T
Y = sin(X);
Z = cos(X);

plot3(X,Y,Z);
