% exo 4
% appel de formeetrange
affichage(@formeetrange,[-2 2, -2 2])
