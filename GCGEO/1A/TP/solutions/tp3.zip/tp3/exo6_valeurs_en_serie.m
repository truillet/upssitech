# exercice 7

V = Fibonacci(16);
stem(V);
print("fibo16.jpg","-djpeg");
