# exercice1

X = [0:0.1:2*pi];

Y1 = cos(X);
Y2 = sin(X);

plot(X,Y1);
hold on
plot(X,Y2,"r");
xlabel("abscisses");
ylabel("ordonnees");
title("Fonctions trigonometriques");
legend("cos(x)", "sin(x)");
