# exercice8

M =load("-ascii","accelero.csv");

temps = M(:,1);
temps = temps-temps(1); # remise à zero du temps
X = M(:,2);
Y = M(:,3);
Z = M(:,4);

plot3(temps, X,Y,"b");
hold on;
plot3(temps, X,Z,"g");
xlabel("temps");
legend("t,X,Y", "t,X,Z");
print("image.png","-dpng");