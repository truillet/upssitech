function dxdt=oscillateur(t,x)
	k=10 ;
	m=10 ;
	dxdt(1)=x(2);
	dxdt(2)=-(k/m)*x(1);
	dxdt=dxdt'; % on convertit la ligne en colonnes
end
