function affichage(bornes)
  x = [bornes(1):0.1:bornes(2)];
  y = [bornes(3):0.1:bornes(4)];
  [X,Y] = meshgrid(x,y);
  Z = formeetrange(X,Y);
  mesh(X,Y,Z);
end