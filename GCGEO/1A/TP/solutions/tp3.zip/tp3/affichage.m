function affichage(f,bornes)
  x = [bornes(1):0.1:bornes(2)];
  y = [bornes(3):0.1:bornes(4)];
  [X,Y] = meshgrid(x,y);
  % on appelle la fonction f
  Z = f(X,Y);
  mesh(X,Y,Z);
  xlabel('x')
  ylabel('y')
  zlabel('z')
  grid on
end
