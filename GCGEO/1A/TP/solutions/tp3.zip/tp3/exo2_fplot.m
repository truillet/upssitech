% fplot 
fplot('x.^2-2','k');