function affiche_racine(f)
  # calcul du determinant
  delta = f(2).^2 - 4*f(1)*f(3);

  if delta > 0 # 2 racines
    x1 = (-f(2) - sqrt(delta))/(2*f(1));
    x2 = (-f(2) + sqrt(delta))/(2*f(1));
    
    # affichage de la courbe
    X = [min([x1 x2])-2:0.1:max([x1 x2])+1];
    Y = f(1)*X.^2 + f(2)*X + f(3);
    hold off;
    plot(X,Y);
    hold on;
    grid on;
    # affichage des racines
    plot(x1,0, "ro");
    text(x1,-1,sprintf("%.2f",x1));   
    plot(x2,0, "ro");
    text(x2,-1,sprintf("%.2f",x2));
    hold on;
  elseif delta == 0 # 1 racine  
    x1 = -f(2)/(2*f(1));
    # affichage de la courbe
    X = [x1-2:0.1:x1+1];
    Y = f(1)*X.^2 + f(2)*X + f(3);
    hold off;
    plot(X,Y);
    hold on;
    grid on;
    # affichage des racines
    plot(x1,0, "ro");
    text(x1,-1,sprintf("%.2f",x1));
  else # pas de racine réelle  
    X = [-2:0.1:2];
    Y = f(1)*X.^2 + f(2)*X + f(3);
    hold off;
    plot(X,Y);
    hold on;
    grid on;
  end 
  #message = functionToString(f);
  message = polyout(f);
  legend(message); 
  xlabel("x");
  ylabel("y"); 
end