# exercice 6

inscrits = 1412;

labels = {'Louis','Jeanne','Maurice','Albertine'};
resultats = [231 424 489 12];

pc = sprintf("Participation : %.2f %%",(sum(resultats)/inscrits)*100);
pie(resultats,labels);
legend(pc);

