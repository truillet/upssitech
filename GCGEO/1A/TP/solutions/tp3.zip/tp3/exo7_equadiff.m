% oscillateur entre le temps tinit=0 et tfin=100
% avec les valeurs initiales de x(0)=0 et dx/dt(0)=0.25
[t,x] = ode45(@oscillateur,[0 100], [0, 0.25]);
subplot(2,1,1);
  plot(t,x(:,1)); % extraction de x(t)
subplot(2,1,2);
  plot(x(:,1), x(:,2),'r') % plan de phase
  axis equal