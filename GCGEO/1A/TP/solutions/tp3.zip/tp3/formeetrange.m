function z=formeetrange(x,y)
  z = cos(3.*(x.^2+y.^2).^1/3);
end